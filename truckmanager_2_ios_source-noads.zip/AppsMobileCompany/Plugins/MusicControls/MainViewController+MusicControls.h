//
//  MainViewController+MusicControls.h
//  
//
//  Created by Juan Gonzalez on 12/17/16.
//
//

#ifndef MainViewController_MusicControls_h
#define MainViewController_MusicControls_h

#import "MainViewController.h"

@interface MainViewController (MusicControls)

@end


#endif /* MainViewController_MusicControls_h */
